http://kusar.ch/2016/02/send-email-with-angular-and-php/
